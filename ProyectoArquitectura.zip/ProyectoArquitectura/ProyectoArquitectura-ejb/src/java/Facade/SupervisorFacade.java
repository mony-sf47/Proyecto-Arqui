/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Facade;

import Entity.Supervisor;
import java.util.List;
import javax.ejb.Stateless;
import javax.ejb.LocalBean;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

/**
 *
 * @author Equipo #5
 * @fecha 19/11/2017
 */
@Stateless
@LocalBean
public class SupervisorFacade {

    @PersistenceContext(unitName = "ProyectoArquitectura-ejbPU")
    private EntityManager em;
    
    /*Funcion para obtener la lista de sensores*/
    public List<Supervisor> findAll() {
        TypedQuery<Supervisor> query; // Variable tipo TypedQuery para generar una lista
        query = em.createQuery("SELECT S FROM Supervisor S", Supervisor.class); // Query 
        return query.getResultList();
    }

    /*Funcion para obtener el boleto buscado por su id, mandando como parametro el id del supervisor*/
    public Supervisor findById(Long idSupervisor) {
        TypedQuery query; // Variable tipo TypedQuery
        query = em.createQuery("SELECT S FROM Supervisor S WHERE S.id=:idSupervisor", Supervisor.class); // Query 
        query.setParameter("idSupervisor", idSupervisor);
        return (Supervisor) query.getSingleResult();
    }
    
    public Long findByLogin(String user, String password) {
        TypedQuery query; // Variable tipo TypedQuery
        query = em.createQuery("SELECT COUNT(S) FROM Supervisor S WHERE S.usuario=:user AND S.password=:password", Supervisor.class); // Query 
        query.setParameter("user", user);
        query.setParameter("password", password);
        return (Long) query.getSingleResult();
    }
    
    /*Funcion para insertar un nuevo registro*/
    public void insert(Supervisor s) {
        em.persist(s);
    }

    /*Funcion para actualizar un registro*/
    public void update(Supervisor s) {
        em.merge(s);
    }

    /*Funcion para eliminar un registro*/
    public void delete(Supervisor s) {
        em.remove(em.merge(s));
    }
    
}
