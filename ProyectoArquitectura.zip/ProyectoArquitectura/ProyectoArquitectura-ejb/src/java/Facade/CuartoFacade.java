/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Facade;

import Entity.Cuarto;
import java.util.List;
import javax.ejb.Stateless;
import javax.ejb.LocalBean;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

/**
 *
 * @author Equipo #5
 * @fecha 19/11/2017
 */
@Stateless
@LocalBean
public class CuartoFacade {

    @PersistenceContext(unitName = "ProyectoArquitectura-ejbPU")
    private EntityManager em;
    
    /*Funcion para obtener la lista de cuartos*/
    public List<Cuarto> findAll() {
        TypedQuery<Cuarto> query; // Variable tipo TypedQuery para generar una lista
        query = em.createQuery("SELECT C FROM Cuarto C", Cuarto.class); // Query 
        return query.getResultList();
    }

    /*Funcion para obtener el boleto buscado por su id, mandando como parametro el id del cuarto*/
    public Cuarto findById(Long idCuarto) {
        TypedQuery query; // Variable tipo TypedQuery
        query = em.createQuery("SELECT C FROM Cuarto C WHERE C.id=:idCuarto", Cuarto.class); // Query 
        query.setParameter("idCuarto", idCuarto);
        return (Cuarto) query.getSingleResult();
    }
    
    public Cuarto findRegister(Long idCuarto) {
        TypedQuery query; // Variable tipo TypedQuery
        query = em.createQuery("SELECT C.numero FROM Cuarto C WHERE C.id=:idCuarto", Cuarto.class); // Query 
        query.setParameter("idCuarto", idCuarto);
        return (Cuarto) query.getSingleResult();
    }
    
    /*Funcion para insertar un nuevo registro*/
    public void insert(Cuarto c) {
        em.persist(c);
    }

    /*Funcion para actualizar un registro*/
    public void update(Cuarto c) {
        em.merge(c);
    }

    /*Funcion para eliminar un registro*/
    public void delete(Cuarto c) {
        em.remove(em.merge(c));
    }
    
}
