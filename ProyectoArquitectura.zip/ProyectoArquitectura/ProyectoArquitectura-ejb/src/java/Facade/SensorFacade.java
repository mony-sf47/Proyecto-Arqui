/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Facade;

import Entity.Sensor;
import java.util.List;
import javax.ejb.Stateless;
import javax.ejb.LocalBean;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

/**
 *
 * @author Equipo #5
 * @fecha 19/11/2017
 */
@Stateless
@LocalBean
public class SensorFacade {

    @PersistenceContext(unitName = "ProyectoArquitectura-ejbPU")
    private EntityManager em;
    
    /*Funcion para obtener la lista de sensores*/
    public List<Sensor> findAll() {
        TypedQuery<Sensor> query; // Variable tipo TypedQuery para generar una lista
        query = em.createQuery("SELECT S FROM Sensor S", Sensor.class); // Query 
        return query.getResultList();
    }

    /*Funcion para obtener el boleto buscado por su id, mandando como parametro el id del sensor*/
    public Sensor findById(Long idSensor) {
        TypedQuery query; // Variable tipo TypedQuery
        query = em.createQuery("SELECT S FROM Sensor S WHERE S.id=:idSensor", Sensor.class); // Query 
        query.setParameter("idSensor", idSensor);
        return (Sensor) query.getSingleResult();
    }
    
    /*Funcion para insertar un nuevo registro*/
    public void insert(Sensor s) {
        em.persist(s);
    }

    /*Funcion para actualizar un registro*/
    public void update(Sensor s) {
        em.merge(s);
    }

    /*Funcion para eliminar un registro*/
    public void delete(Sensor s) {
        em.remove(em.merge(s));
    }
    
}
