/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entity;

import java.io.Serializable;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 *
 * @author Equipo #5
 * @fecha 19/11/2017
 */
@Entity
@Table(schema = "SIGMASCHEMA") // Tabla que se creara en el esquema SIGMASCHEMA
public class Cuarto implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(name = "numero", nullable = false)
    private int numero;
    
    @Column(name = "temperatura_base", nullable = false)
    private double temperatura_base;
    
    @Column(name = "cant_H", nullable = false, length = 3)
    private int cant_H;
    
    @Column(name = "cant_C", nullable = false, length = 3)
    private int cant_C;
    
    @Column(name = "cant_T", nullable = false, length = 3)
    private int cant_T;
    
    @OneToMany(cascade = CascadeType.MERGE, mappedBy = "cuarto")
    private List<Sensor> sensor; // Lista de sensores
    
    @ManyToOne(optional = false)
    @JoinColumn(referencedColumnName = "id", name = "supervisor")
    private Supervisor supervisor;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Cuarto)) {
            return false;
        }
        Cuarto other = (Cuarto) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Entity.Cuarto[ id=" + id + " ]";
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public double getTemperatura_base() {
        return temperatura_base;
    }

    public void setTemperatura_base(double temperatura_base) {
        this.temperatura_base = temperatura_base;
    }

    public Supervisor getSupervisor() {
        return supervisor;
    }

    public void setSupervisor(Supervisor supervisor) {
        this.supervisor = supervisor;
    }

    public List<Sensor> getSensor() {
        return sensor;
    }

    public void setSensor(List<Sensor> sensor) {
        this.sensor = sensor;
    }

    public int getCant_H() {
        return cant_H;
    }

    public void setCant_H(int cant_H) {
        this.cant_H = cant_H;
    }

    public int getCant_C() {
        return cant_C;
    }

    public void setCant_C(int cant_C) {
        this.cant_C = cant_C;
    }

    public int getCant_T() {
        return cant_T;
    }

    public void setCant_T(int cant_T) {
        this.cant_T = cant_T;
    }
    
}
