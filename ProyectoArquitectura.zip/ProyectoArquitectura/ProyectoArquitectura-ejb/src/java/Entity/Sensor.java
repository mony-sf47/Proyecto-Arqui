/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author Equipo #5
 * @fecha 19/11/2017
 */
@Entity
@Table(schema = "SIGMASCHEMA") // Tabla que se creara en el esquema SIGMASCHEMA
public class Sensor implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(name = "grado_H", nullable = false)
    private double grado_H;
    
    @Column(name = "grado_C", nullable = false)
    private double grado_C;
    
    @Column(name = "grado_T", nullable = false)
    private double grado_T;
    
    @Column(name = "fecha", nullable = false)
    @Temporal(TemporalType.DATE)         
    private Date fecha;
    
    @Column(name = "hora", nullable = false)
    @Temporal(TemporalType.TIME)         
    private Date hora;
    
    @ManyToOne(optional = false)
    @JoinColumn(nullable = false, referencedColumnName = "id", name = "cuarto")
    private Cuarto cuarto; // Mapea entera la entidad

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Sensor)) {
            return false;
        }
        Sensor other = (Sensor) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Entity.Sensor[ id=" + id + " ]";
    }

    public Cuarto getCuarto() {
        return cuarto;
    }

    public void setCuarto(Cuarto cuarto) {
        this.cuarto = cuarto;
    }

    public double getGrado_H() {
        return grado_H;
    }

    public void setGrado_H(double grado_H) {
        this.grado_H = grado_H;
    }

    public double getGrado_C() {
        return grado_C;
    }

    public void setGrado_C(double grado_C) {
        this.grado_C = grado_C;
    }

    public double getGrado_T() {
        return grado_T;
    }

    public void setGrado_T(double grado_T) {
        this.grado_T = grado_T;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public Date getHora() {
        return hora;
    }

    public void setHora(Date hora) {
        this.hora = hora;
    }
    
}
