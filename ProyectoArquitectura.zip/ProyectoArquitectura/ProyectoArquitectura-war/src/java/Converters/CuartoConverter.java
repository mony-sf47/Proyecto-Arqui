package Converters;

import Controller.CuartoController;
import Entity.Cuarto;
import javax.faces.component.UIComponent; 
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter; //Permite la implementacion de un converter.
import javax.faces.convert.FacesConverter;

/**
 *
 * @author Equipo #5
 * @date 21/11/2017
 */

@FacesConverter(forClass = Cuarto.class)
public class CuartoConverter implements Converter{

    @Override
    //Metodo que convierte un string en un objeto.
    public Object getAsObject(FacesContext context, UIComponent component, String value) {
        CuartoController cc = context.getApplication().evaluateExpressionGet(context, "#{ cuartoController }", 
                            CuartoController.class);
        return cc.findById(Long.parseLong(value));
    }

    @Override
    //Metodo que convierte un objeto en un string.
    public String getAsString(FacesContext context, UIComponent component, Object value) {
        Cuarto c = (Cuarto)value;
        return c.getId().toString();
    }
    
}
