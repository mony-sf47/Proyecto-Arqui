package Converter;

import Controller.SensorController;
import Entity.Sensor;
import javax.faces.component.UIComponent; 
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter; //Permite la implementacion de un converter.
import javax.faces.convert.FacesConverter;

/**
 *
 * @author Equipo #5
 * @date 21/11/2017
 */

@FacesConverter(forClass = Sensor.class)
public class SensorConverter implements Converter{

    @Override
    //Metodo que convierte un string en un objeto.
    public Object getAsObject(FacesContext context, UIComponent component, String value) {
        SensorController sc = context.getApplication().evaluateExpressionGet(context, "#{ sensorController }", 
                            SensorController.class);
        return sc.findById(Long.parseLong(value));
    }

    @Override
    //Metodo que convierte un objeto en un string.
    public String getAsString(FacesContext context, UIComponent component, Object value) {
        Sensor s = (Sensor)value;
        return s.getId().toString();
    }
    
}
