/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Entity.Supervisor;
import Facade.SupervisorFacade;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.util.List;
import javax.ejb.EJB;
import javax.ejb.EJBException;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

/**
 *
 * @author Equipo #5
 * @fecha 19/11/2017
 */
@Named(value = "supervisorController")
@SessionScoped
public class SupervisorController implements Serializable {

    @EJB
    SupervisorFacade facade;
    private Supervisor obj;
    private boolean updateFlag;

    /*Funcion que manda a llamar al facade de la entidad 
    para conectarse y obtener la lista requerida*/
    public List<Supervisor> findAll() {
        return facade.findAll();
    }

    /*Funcion que manda a llamar al facade de la entidad 
    para conectarse y obtener la lista requerida*/
    public Supervisor findById(Long idSupervisor) {
        return facade.findById(idSupervisor);
    }

    public Long findByLogin(String user, String password) {
        return facade.findByLogin(user, password);
    }

    public boolean validate() {
        if (obj.getUsuario() != null) {
            return true;
        }
        FacesMessage msj = new FacesMessage(
                FacesMessage.SEVERITY_WARN,
                "Seleccione un supervisor.", //no
                ""
        );
        FacesContext.getCurrentInstance().addMessage("SupervisorForm:message", msj);
        return false;
    }

    public String validateLogin() {
        if (findByLogin(obj.getUsuario(), obj.getPassword()) <= 0) {
            FacesMessage msj = new FacesMessage(
                    FacesMessage.SEVERITY_WARN,
                    "Usuario y/o contraseña no validos.", //no
                    ""
            );
            FacesContext.getCurrentInstance().addMessage("index:message", msj);
            return clean("index.xhtml");
        }
        return "home.xhtml";
    }

    /*Funcion para limpiar la lista/formulario*/
    public String clean(String direccion) {
        obj = new Supervisor();
        this.updateFlag = false;
        return direccion;
    }

    /*Funcion para añadir un nuevo registro*/
    public String insert() {
        if (this.validate()) {
            facade.insert(obj);
            return clean("SupervisorList");
        } else {
            return "SupervisorForm";
        }
    }

    /*Funcion para preparar el update*/
    public String prepareUpdate(Supervisor o) {
        this.obj = o;
        this.updateFlag = true;
        return "SupervisorForm";
    }

    /*Funcion para actualizar un registro*/
    public String update() {
        if (this.validate()) {
            facade.update(obj);
            return clean("SupervisorList");
        } else {
            return "SupervisorForm";
        }
    }

    /*Funcion para preparar el delete*/
    public String prepareDelete(Supervisor o) {
        this.obj = o;
        return "SupervisorList";
    }

    /*Funcion para eliminar un registro*/
    public String delete() {
        try {
            facade.delete(obj);
            return clean("SupervisorList");
        } catch (EJBException e) {
            FacesMessage msj = new FacesMessage(
                    FacesMessage.SEVERITY_WARN,
                    "No se puede borrar el Supervisor porque cuenta con hijos",
                    ""
            );
            FacesContext.getCurrentInstance().addMessage("SupervisorList:message", msj);
            return clean("SupervisorList");
        }
    }

    public Supervisor getObj() {
        if (obj == null) {
            obj = new Supervisor();
        }
        return obj;
    }

    public void setObj(Supervisor obj) {
        this.obj = obj;
    }

    public boolean isUpdateFlag() {
        return updateFlag;
    }

    public void setUpdateFlag(boolean updateFlag) {
        this.updateFlag = updateFlag;
    }

}
