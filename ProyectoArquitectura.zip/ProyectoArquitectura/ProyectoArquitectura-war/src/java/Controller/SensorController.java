/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Entity.Sensor;
import Facade.SensorFacade;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Random;
import javax.ejb.EJB;
import javax.ejb.EJBException;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

/**
 *
 * @author Equipo #5
 * @fecha 19/11/2017
 */
@Named(value = "sensorController")
@SessionScoped
public class SensorController implements Serializable {

    @EJB
    SensorFacade facade;
    private Sensor obj;
    private boolean updateFlag;
    Date today = new Date();
    
    /*Funcion que manda a llamar al facade de la entidad 
    para conectarse y obtener la lista requerida*/
    public List<Sensor> findAll() {
        return facade.findAll();
    }

    /*Funcion que manda a llamar al facade de la entidad 
    para conectarse y obtener la lista requerida*/
    public Sensor findById(Long idSensor) {
        return facade.findById(idSensor);
    }
    
    public boolean validate() {
        if (obj.getCuarto() != null) {
            return true;
        }
        FacesMessage msj = new FacesMessage(
                FacesMessage.SEVERITY_WARN,
                "Seleccione un cuarto.",
                ""
        );
        FacesContext.getCurrentInstance().addMessage("SensorForm:message", msj);
        return false;
    }
    
    /*Funcion para limpiar la lista/formulario*/
    public String clean(String direccion) {
        obj = new Sensor();
        this.updateFlag = false;
        return direccion;
    }

    /*Funcion para añadir un nuevo registro*/
    public String insert(String tipo) {
        Random randomGenerator = new Random();
        if (this.validate()) {
            if(tipo.equals("generar")) {
                obj.setGrado_C(randomGenerator.nextInt(40) -20);
                obj.setGrado_H(randomGenerator.nextInt(40) -20);
                obj.setGrado_T(randomGenerator.nextInt(40) -20);
                obj.setFecha(today);
                obj.setHora(today);
                facade.insert(obj);
                return "GenerarForm";
            }
            facade.insert(obj);
            return clean("SensorList");
        } else {
            if(tipo.equals("generar")) {
                return "GenerarForm";
            }
            return "SensorForm";
        }
    }

    /*Funcion para preparar el update*/
    public String prepareUpdate(Sensor o) {
        this.obj = o;
        this.updateFlag = true;
        return "SensorForm";
    }

    /*Funcion para actualizar un registro*/
    public String update() {
        if (this.validate()) {
            facade.update(obj);
            return clean("SensorList");
        } else {
            return "SensorForm";
        }
    }

    /*Funcion para preparar el delete*/
    public String prepareDelete(Sensor o) {
        this.obj = o;
        return "SensorList";
    }

    /*Funcion para eliminar un registro*/
    public String delete() {
        try {
            facade.delete(obj);
            return clean("SensorList");
        } catch (EJBException e) {
            FacesMessage msj = new FacesMessage(
                    FacesMessage.SEVERITY_WARN,
                    "No se puede borrar el Sensor porque cuenta con hijos",
                    ""
            );
            FacesContext.getCurrentInstance().addMessage("SensorList:message", msj);
            return clean("SensorList");
        }
    }

    public Sensor getObj() {
        if (obj == null) {
            obj = new Sensor();
        }
        return obj;
    }

    public void setObj(Sensor obj) {
        this.obj = obj;
    }

    public boolean isUpdateFlag() {
        return updateFlag;
    }

    public void setUpdateFlag(boolean updateFlag) {
        this.updateFlag = updateFlag;
    }
    
}
