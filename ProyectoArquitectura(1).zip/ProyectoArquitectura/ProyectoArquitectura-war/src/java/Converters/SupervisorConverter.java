package Converters;

import Controller.SupervisorController;
import Entity.Supervisor;
import javax.faces.component.UIComponent; 
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter; //Permite la implementacion de un converter.
import javax.faces.convert.FacesConverter;

/**
 *
 * @author Equipo #5
 * @date 21/11/2017
 */

@FacesConverter(forClass = Supervisor.class)
public class SupervisorConverter implements Converter{

    @Override
    //Metodo que convierte un string en un objeto.
    public Object getAsObject(FacesContext context, UIComponent component, String value) {
        SupervisorController sc = context.getApplication().evaluateExpressionGet(context, "#{ supervisorController }", 
                            SupervisorController.class);
        return sc.findById(Long.parseLong(value));
    }

    @Override
    //Metodo que convierte un objeto en un string.
    public String getAsString(FacesContext context, UIComponent component, Object value) {
        Supervisor s = (Supervisor)value;
        return s.getId().toString();
    }
    
}

