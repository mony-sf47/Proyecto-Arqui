/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Entity.Cuarto;
import Facade.CuartoFacade;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.util.List;
import javax.ejb.EJB;
import javax.ejb.EJBException;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

/**
 *
 * @author Equipo #5
 * @fecha 19/11/2017
 */
@Named(value = "cuartoController")
@SessionScoped
public class CuartoController implements Serializable {

    @EJB
    CuartoFacade facade;
    private Cuarto obj;
    private boolean updateFlag;

    /*Funcion que manda a llamar al facade de la entidad 
    para conectarse y obtener la lista requerida*/
    public List<Cuarto> findAll() {
        return facade.findAll();
    }

    /*Funcion que manda a llamar al facade de la entidad 
    para conectarse y obtener la lista requerida*/
    public Cuarto findById(Long idCuarto) {
        return facade.findById(idCuarto);
    }
    
    public Cuarto findRegister(Long idCuarto) {
        return facade.findRegister(idCuarto);
    }

    public boolean validate() {
        if (obj.getSupervisor() != null) {
            return true;
        }
        FacesMessage msj = new FacesMessage(
                FacesMessage.SEVERITY_WARN,
                "Seleccione un supervisor.",
                ""
        );
        FacesContext.getCurrentInstance().addMessage("CuartoForm:message", msj);
        return false;
    }

    /*Funcion para limpiar la lista/formulario*/
    public String clean(String direccion) {
        obj = new Cuarto();
        this.updateFlag = false;
        return direccion;
    }

    /*Funcion para añadir un nuevo registro*/
    public String insert() {
        if (this.validate()) {
            facade.insert(obj);
            return clean("CuartoList");
        } else {
            return "CuartoForm";
        }
    }

    /*Funcion para preparar el update*/
    public String prepareUpdate(Cuarto o) {
        this.obj = o;
        this.updateFlag = true;
        return "CuartoForm";
    }

    /*Funcion para actualizar un registro*/
    public String update() {
        if (this.validate()) {
            facade.update(obj);
            return clean("CuartoList");
        } else {
            return "CuartoForm";
        }
    }

    /*Funcion para preparar el delete*/
    public String prepareDelete(Cuarto o) {
        this.obj = o;
        return "CuartoList";
    }

    /*Funcion para eliminar un registro*/
    public String delete() {
        try {
            facade.delete(obj);
            return clean("CuartoList");
        } catch (EJBException e) {
            FacesMessage msj = new FacesMessage(
                    FacesMessage.SEVERITY_WARN,
                    "No se puede borrar el Cuarto porque cuenta con hijos",
                    ""
            );
            FacesContext.getCurrentInstance().addMessage("CuartoList:message", msj);
            return clean("CuartoList");
        }
    }

    public String generarReporte(Cuarto o) {
        this.obj = o;
        return "ReporteForm";
    }

    public Cuarto getObj() {
        if (obj == null) {
            obj = new Cuarto();
        }
        return obj;
    }

    public void setObj(Cuarto obj) {
        this.obj = obj;
    }

    public boolean isUpdateFlag() {
        return updateFlag;
    }

    public void setUpdateFlag(boolean updateFlag) {
        this.updateFlag = updateFlag;
    }

}
